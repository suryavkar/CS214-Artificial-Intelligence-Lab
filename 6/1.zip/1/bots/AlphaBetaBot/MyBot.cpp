/*
* @file botTemplate.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Template for users to create their own bots
*/

#include <chrono>
#include "Othello.h"
#include "OthelloPlayer.h"
#include "OthelloBoard.h"

using namespace std;
using namespace Desdemona;

#define INT_MIN -2147483648
#define INT_MAX +2147483647

auto start = chrono::steady_clock::now();

class MyBot : public OthelloPlayer
{
public:
    MyBot(Turn turn);

    virtual Move play(const OthelloBoard &board);
    virtual int AlphaBeta(OthelloBoard &board, Turn turn, int depth, Move move,int alpha,int beta);
    virtual int heuristicValue(OthelloBoard &board, int mode = 0);
};

MyBot::MyBot(Turn turn) : OthelloPlayer(turn) {}

Move MyBot::play(const OthelloBoard &board)
{
    start = chrono::steady_clock::now();
    list<Move> selfMoves = board.getValidMoves(turn);
    Move bestMove = *selfMoves.begin();
    int bestScore = INT_MIN;
    int depth = 4;
    
    for (auto move : selfMoves)
    {
        OthelloBoard currentBoardConfig = OthelloBoard(board);
        int hValue = AlphaBeta(currentBoardConfig, this->turn, depth, move, INT_MIN, INT_MAX);

        if (hValue > bestScore)
        {
            bestMove = move;
            bestScore = hValue;
        }

        if (hValue == INT_MIN)
            return bestMove;
    }
  
    return bestMove;
}

int MyBot::AlphaBeta(OthelloBoard &board, Turn turn, int depth, Move move,int alpha, int beta)
{
    if (chrono::duration_cast<chrono::milliseconds>(chrono::steady_clock::now() - start).count() > 1900)
        return INT_MIN;

    OthelloBoard nextBoardConfig = OthelloBoard(board);
    nextBoardConfig.makeMove(turn, move);
    list<Move> gameTree = nextBoardConfig.getValidMoves(other(turn));
    int best_value;
    //printf("MIN: %d, MAX, %d \n", alpha, beta);
    /*
     printf("Exploring : (%d, %d),\t depth = %d,\t No. children - %d \n", move.x, move.y, depth, moveTree.size());
    int branchNodes = 0;
    for (Move child : moveTree)
    {
        OthelloBoard intermediateBoard = OthelloBoard(board);
        intermediateBoard.makeMove(turn, move);
        printf("Child - %d ==> (%d, %d) :\t Heuristic Value: %d\n", branchNodes, child.x, child.y, heuristicForMinMax(intermediateBoard, HeuristicFunNo));
        branchNodes++;
    }
    */
    if (depth == 0)
        return heuristicValue(nextBoardConfig);
    else if(turn==1)
    {	
	for(auto move: gameTree)
	{
		alpha = max(alpha, AlphaBeta(nextBoardConfig, other(turn), depth-1, move, alpha, beta));
	if(alpha >= beta)
		return beta;
	}
	return alpha;
		
    }
    else
    {
    	for(auto move : gameTree)
	{
		beta = min(beta, AlphaBeta(nextBoardConfig, other(turn), depth-1,move, alpha, beta));
		if(alpha >= beta)
			return alpha;
	}
	return beta;
    }
    
    return best_value;
   }

int MyBot::heuristicValue(OthelloBoard &board, int mode)
{   
    // 0 : Mobiity 1 : CoinParity
    switch (mode)
    {
    	case 0:
  	{
		int numOppMoves = board.getValidMoves(other(this->turn)).size();
		int numSelfMoves = board.getValidMoves(this->turn).size();

		if(numOppMoves + numSelfMoves != 0)
		{
			return 100*(numSelfMoves - numOppMoves)/(numOppMoves + numSelfMoves);
		}
		else
			return 0;
  	}
	case 1:
	{
		if(this->turn == 1)
			return (board.getBlackCount() - board.getRedCount());
		return (board.getRedCount() - board.getBlackCount());
	}
    	default:
    	    return 0;
    }
}
// The following lines are _very_ important to create a bot module for Desdemona
extern "C"
{
    OthelloPlayer *createBot(Turn turn)
    {
        return new MyBot(turn);
    }

    void destroyBot(OthelloPlayer *bot)
    {
        delete bot;
    }
}
