Use python version : 3.9.7

The file “1.py” can be run from command line using python3 as follows:
python3 1.py -i input_number -hf heuristic_func_number
Command line arguments:
a. -i input_number : Select one of the input configurations (start and goal node) from 1/2.
b. -hf heuristic_func_number : Select one of the Heuristic functions from 1/2/3.