Run the script as follows:

```
    $ ./run.sh <input_file>
```

This will display the output in the terminal

OR

python 1.py <input_file>


## Additional Information:

python version 3.9.7 is used